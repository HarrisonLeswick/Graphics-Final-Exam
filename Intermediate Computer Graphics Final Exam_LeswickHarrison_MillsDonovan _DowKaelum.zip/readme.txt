=============================================================
Intermediate Computer Graphics Final Exam
=============================================================
Harrison Leswick (100788569)
Donovan  Mills (100801916)
Kaelum Dow (100791139)
